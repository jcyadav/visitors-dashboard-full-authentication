<aside>
    <div id="sidebar" class="nav-collapse">

        <ul class="sidebar-menu" id="nav-accordion">

            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($menu->children->count()): ?>

                    <li class="sub-menu">

                        <a href="javascript:;">
                            <i class="<?php echo e($menu->tab_icon_class); ?>"></i>
                            <span><?php echo e($menu->tab_name); ?></span>
                        </a>

                        <ul class="sub">

                            <?php $__currentLoopData = $menu->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php

                                    $route = '#';

                                    switch ($child->link_url) {

                                        case 'MyAccount/MyProfile.php':
                                            $route = route('MyProfile');
                                            break;

                                        case 'Assessment/qone.php':
                                            $route = route('qone');
                                            break;

                                        case 'Assessment/qtwo.php':
                                            $route = route('qtwo');
                                            break;

                                        case 'Assessment/qthree.php':
                                            $route = route('qthree');
                                            break;
                                    }

                                ?>

                                <li>
                                    <a href="<?php echo e($route); ?>">
                                        <?php echo e($child->tab_name); ?>

                                    </a>
                                </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>

                    </li>

                <?php else: ?>

                    <?php

                        $route = '#';

                        switch ($menu->link_url) {

                            case 'Dashboard.php':
                                $route = route('Dashboard');
                                break;

                            case 'Logout.php':
                                $route = route('Logout');
                                break;
                        }

                    ?>

                    <li>

                        <a href="<?php echo e($route); ?>">

                            <i class="<?php echo e($menu->tab_icon_class); ?>"></i>

                            <span><?php echo e($menu->tab_name); ?></span>

                        </a>

                    </li>

                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

    </div>
</aside><?php /**PATH E:\Laravel Projects\codegenie\backend\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>