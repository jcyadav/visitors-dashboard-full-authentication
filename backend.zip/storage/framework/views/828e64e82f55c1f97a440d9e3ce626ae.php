

<?php $__env->startSection('content'); ?>

<section id="main-content">
<section class="wrapper">

<div class="row">

<div class="col-md-12">

<div class="panel panel-default">

<div class="panel-heading">
    <h3 class="panel-title">
        <i class="fa fa-user"></i> My Profile
    </h3>
</div>

<div class="panel-body">

<div class="row">

<div class="col-md-3 text-center">

<img src="<?php echo e(asset('images/2.png')); ?>"
     class="img-circle"
     width="140">

<br><br>

<h4><?php echo e($user->full_name); ?></h4>

<span class="label label-success">
    <?php echo e($user->is_active); ?>

</span>

</div>

<div class="col-md-9">

<table class="table table-bordered table-striped">

<tr>
<th width="30%">Full Name</th>
<td><?php echo e($user->full_name); ?></td>
</tr>

<tr>
<th>Email Address</th>
<td><?php echo e($user->email_id); ?></td>
</tr>

<tr>
<th>Mobile Number</th>
<td><?php echo e($user->mobile_number); ?></td>
</tr>

<tr>
<th>Account Status</th>
<td>
<span class="label label-success">
<?php echo e($user->is_active); ?>

</span>
</td>
</tr>

<tr>
<th>Created On</th>
<td><?php echo e($user->created_on); ?></td>
</tr>

<tr>
<th>Last Login IP</th>
<td><?php echo e($user->last_login_ip ?? 'N/A'); ?></td>
</tr>

</table>

</div>

</div>

</div>

</div>

</div>

</div>

</section>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Laravel Projects\codegenie\backend\resources\views/pages/myprofile.blade.php ENDPATH**/ ?>